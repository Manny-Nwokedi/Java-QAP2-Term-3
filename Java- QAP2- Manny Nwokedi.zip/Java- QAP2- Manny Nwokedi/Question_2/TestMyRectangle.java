package Question_2;

public class TestMyRectangle {
    public static void main(String[] args) {
        // Create MyPoint instances
        MyPoint point1 = new MyPoint(5, 8);
        MyPoint point2 = new MyPoint(4, 2);
        MyPoint insidePoint = new MyPoint(3, 2);

        // Create MyRectangle instances
        MyRectangle rectangle1 = new MyRectangle(5, 8, 4, 2);
        MyRectangle rectangle2 = new MyRectangle(point1, point2);

        // Test getter and setter methods
        System.out.println("Rectangle 1: " + rectangle1.toString());
        System.out.println("Area of Rectangle 1: " + rectangle1.getArea());
        System.out.println("Perimeter of Rectangle 1: " + rectangle1.getPerimeter());

        System.out.println("\nRectangle 2: " + rectangle2.toString());
        System.out.println("Area of Rectangle 2: " + rectangle2.getArea());
        System.out.println("Perimeter of Rectangle 2: " + rectangle2.getPerimeter());

        // Test contains method
        System.out.println("\nDoes Rectangle 1 contain the point " + insidePoint + "? " + rectangle1.contains(insidePoint));
        System.out.println("Does Rectangle 2 contain the point " + insidePoint + "? " + rectangle2.contains(insidePoint));
    }
}