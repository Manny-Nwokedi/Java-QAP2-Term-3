// MyPoint class representing a point in 2D space
public class MyPoint {
    private int x;
    private int y;

    // Constructor to initialize x and y coordinates
    public MyPoint(int x, int y) {
        this.x = x;
        this.y = y;
    }

    // Getter method for x coordinate
    public int getX() {
        return x;
    }

    // Getter method for y coordinate
    public int getY() {
        return y;
    }

    // Setter method for both x and y coordinates
    public void setXY(int x, int y) {
        this.x = x;
        this.y = y;
    }

    // Calculate the distance between two points using distance formula
    public double distance(MyPoint anotherPoint) {
        int xDiff = this.x - anotherPoint.getX();
        int yDiff = this.y - anotherPoint.getY();
        return Math.sqrt(xDiff * xDiff + yDiff * yDiff);
    }

    // Convert point information to a string
    public String toString() {
        return "(" + x + "," + y + ")";
    }
}