public class MyLine {
    private MyPoint begin;
    private MyPoint end;

    // The Constructors
    public MyLine(int x1, int y1, int x2, int y2) {
        this.begin = new MyPoint(x1, y1);
        this.end = new MyPoint(x2, y2);
    }

    public MyLine(MyPoint begin, MyPoint end) {
        this.begin = begin;
        this.end = end;
    }

    // Start and End points
    public MyPoint getBegin() {
        return begin;
    }

    public void setBegin(MyPoint begin) {
        this.begin = begin;
    }

    public MyPoint getEnd() {
        return end;
    }

    public void setEnd(MyPoint end) {
        this.end = end;
    }
    // Calculate the length of the line using MyPoint's distance method
    public double getLength() {
        return begin.distance(end);
    }
    public double getGradient() {
        int yDiff = end.getY() - begin.getY();
        int xDiff = end.getX() - begin.getX();
        return Math.atan2(yDiff, xDiff);
    }

    // Change line informtion to string format
    public String toString() {
        return "MyLine[begin=" + begin + ",end=" + end + "]";
    }
}