// TestMyLine class to test the functionality of MyLine class
public class TestMyLine {
    public static void main(String[] args) {
        // Create MyPoint instances
        MyPoint point1 = new MyPoint(3, 4);
        MyPoint point2 = new MyPoint(6, 2);

        // Create MyLine instances
        MyLine line1 = new MyLine(3, 4, 6, 2);
        MyLine line2 = new MyLine(point1, point2);

        // Test getter and setter methods
        System.out.println("Line 1: " + line1.toString());
        System.out.println("Length of Line 1: " + line1.getLength());
        System.out.println("Gradient of Line 1: " + line1.getGradient());

        System.out.println("\nLine 2: " + line2.toString());
        System.out.println("Length of Line 2: " + line2.getLength());
        System.out.println("Gradient of Line 2: " + line2.getGradient());
    }
}