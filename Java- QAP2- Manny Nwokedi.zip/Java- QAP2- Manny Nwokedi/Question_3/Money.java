
package Question_3;
public class Money {
    private long dollars;
    private long cents;

    public String toString() {
        return String.format("$%d.%02d", dollars, cents);
    }

    public Money(double amount) {
        this.dollars = (long) amount;
        this.cents = Math.round((amount - dollars) * 100);
    }

    public Money(Money otherObject) {
        this.dollars = otherObject.dollars;
        this.cents = otherObject.cents;
    }
    public Money subtract(Money amount) {
        long totalCents = (this.dollars * 100 + this.cents) - (amount.dollars * 100 + amount.cents);
        return new Money(totalCents / 100.0);
    }
    public Money add(Money amount) {
        long totalCents = this.cents + amount.cents;
        long extraDollars = totalCents / 100;
        long totalDollars = this.dollars + amount.dollars + extraDollars;
    
        return new Money(totalDollars + (totalCents % 100) / 100.0);
    }
    public int compareTo(Money other) {
        if (this.dollars == other.dollars) {
            return Long.compare(this.cents, other.cents);
        } else {
            return Long.compare(this.dollars, other.dollars);
        }
    }

    // Other methods (add, subtract, compareTo, equals, toString) go here
}